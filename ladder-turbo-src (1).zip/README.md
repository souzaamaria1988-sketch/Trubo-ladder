# Ladder Turbo (Minecraft Java 1.21.1 - Fabric)

Segure **W** na escada para subir **10x mais rapido**.
Segure **ESPACO** para subir na velocidade normal.

## Como pegar o .jar pronto (celular)
O workflow .github/workflows/build.yml compila tudo no GitHub Actions
e publica ladder-turbo-1.0.0.jar na aba Releases do repositorio.

## Build local (PC)
1. Instale JDK 21.
2. Rode: gradle build
3. O .jar final fica em build/libs/ladder-turbo-1.0.0.jar

## Install
Coloque o .jar na pasta .minecraft/mods com Fabric Loader 0.16+ instalado.

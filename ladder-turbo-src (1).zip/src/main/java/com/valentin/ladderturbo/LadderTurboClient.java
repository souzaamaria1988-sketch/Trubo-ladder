package com.valentin.ladderturbo;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ladder Turbo - ponto de entrada client-side.
 * Minecraft Java 1.21.1 | Fabric Loader
 */
public final class LadderTurboClient implements ClientModInitializer {

    public static final String MOD_ID = "ladderturbo";
    public static final Logger LOGGER = LoggerFactory.getLogger("LadderTurbo");

    @Override
    public void onInitializeClient() {
        LOGGER.info("[LadderTurbo] carregado: segure W na escada = 10x | espaco = normal");
    }
}

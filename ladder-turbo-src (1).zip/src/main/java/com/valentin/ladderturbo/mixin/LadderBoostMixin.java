package com.valentin.ladderturbo.mixin;

import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Nucleo do Ladder Turbo.
 *
 * Regras:
 *  - Segurando W (frente) na escada -> sobe 10x mais rapido.
 *  - Segurando ESPACO               -> velocidade normal (vanilla).
 *  - Agachado, montado ou sem escada -> nada muda.
 *
 * Velocidade vanilla de subida: ~0.118 blocos/tick (2,35 blocos/s).
 * 10x = 1.18 blocos/tick. Somamos +0.08 para compensar a gravidade
 * aplicada no tick seguinte, mantendo a media real proxima de 10x.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class LadderBoostMixin {

    private static final double VELOCIDADE_VANILLA = 0.118D;
    private static final double MULTIPLICADOR      = 10.0D;
    private static final double COMPENSA_GRAVIDADE = 0.08D;

    @Shadow
    public Input input;

    @Inject(method = "tickMovement", at = @At("TAIL"))
    private void ladderturbo$subidaTurbo(CallbackInfo ci) {
        ClientPlayerEntity jogador = (ClientPlayerEntity) (Object) this;

        // Defensivas: sem input, montado em entidade ou fora de escada => vanilla.
        if (this.input == null || jogador.hasVehicle() || !jogador.isClimbing()) {
            return;
        }

        boolean segurandoW      = this.input.pressingForward;
        boolean segurandoEspaco = this.input.jumping;
        boolean agachado        = jogador.isSneaking();

        if (segurandoW && !segurandoEspaco && !agachado) {
            double alvo = (VELOCIDADE_VANILLA * MULTIPLICADOR) + COMPENSA_GRAVIDADE;
            jogador.setVelocity(jogador.getVelocity().x, alvo, jogador.getVelocity().z);
        }
        // Se ESPACO estiver pressionado, nao fazemos nada: vanilla assume (1x).
    }
}
